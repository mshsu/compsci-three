import java.util.*;
import java.util.function.BiPredicate;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class AStarPathingStrategy
        implements PathingStrategy
{
    public class Node {
        Point point;
        double f, g, h;
        Node prior;

        public Node(Point point, Node prior, double g, double h){
            this.point = point;
            this.g = g;
            this.h = h;
            this.f = g + h;
            this.prior = prior;
        }

        public double getF() {
            return f;
        }

        public double getG() {
            return g;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Node node = (Node) o;
            return Objects.equals(point, node.point);
        }

        @Override
        public String toString() {
            return "" + this.point + "f:" + f;
        }
    }

    public List<Point> computePath(Point start, Point end,
                                   Predicate<Point> canPassThrough,
                                   BiPredicate<Point, Point> withinReach,
                                   Function<Point, Stream<Point>> potentialNeighbors)
    {
        // Setup
        List<Point> path = new LinkedList<>();
        PriorityQueue<Node> openList = new PriorityQueue<>(Comparator.comparing(Node::getF).thenComparing(Node::getG));
        HashMap<Point, Node> closedList = new HashMap<>();

        // 1 - Choose/know starting and ending points of path (in args)
        // 2 - Add start node to openList and mark as current
        Node current = new Node(start, null, 0,
                Math.abs(start.getX() - end.getX()) + Math.abs(start.getY() - end.getY()));
        openList.add(current);

        while (!withinReach.test(current.point, end)) {
            // 3 - Analyze all valid adjacent nodes that are not on closedList
            Node finalCurrent = current;
            List<Node> newList = potentialNeighbors.apply(current.point)
                    .filter(canPassThrough)
                    .filter(pt -> !Objects.equals(pt, end)
                            && !Objects.equals(pt, start)
                            && !closedList.containsKey(pt))
                    .map(pt -> new Node(pt, finalCurrent,
                            (finalCurrent.g
                            //Manhattan Distance g:
                            //        + Math.abs(pt.getX() - finalCurrent.point.getX())
                            //        + Math.abs(pt.getY() - finalCurrent.point.getY())),
                            //Euclidean Distance g:
                                    + Math.sqrt(Math.pow(pt.getX() - finalCurrent.point.getX(), 2)
                                    + Math.pow(pt.getY() - finalCurrent.point.getY(), 2))),
                            //Manhattan Distance h:
                            Math.abs(pt.getX() - end.getX()) + Math.abs(pt.getY() - end.getY())
                            //Euclidean Distance h:
                            //Math.sqrt(Math.pow(pt.getX() - end.getX(), 2) + Math.pow(pt.getY() - end.getY(), 2))
                    ))
                    .collect(Collectors.toList());

            for (Node newNode : newList) {
                openList.removeIf(pt -> (Objects.equals(pt, newNode)) && (pt.g > newNode.g));
                if (!openList.contains(newNode))
                    openList.add(newNode);
            }

            // 4 - Move current Node to the closedList
            openList.remove(current);
            closedList.put(current.point, current);

            // 5 - Choose a node from the openList with the smallest f
//            openList.sort(Comparator.comparing(Node::getF));
            current = openList.peek();
            if (current == null) return path;

            // 6 - go to step 3
            // 7 - repeat until a path to the end is found
        }

        while (current.prior != null) {
            path.add(0, current.point);
            current = current.prior;
        }

        return path;
    }
}
