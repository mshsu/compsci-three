import processing.core.PImage;

import java.util.List;
import java.util.Optional;

public class CarEntity extends ActiveEntity{
    private int maxX;
    private int maxY;
    private int minX;
    private int minY;

    public CarEntity(String id, List<PImage> images, int animationPeriod, int actionPeriod,
                     int maxX, int minX, int maxY, int minY) {
        super(id, new Point (minX, minY), images, animationPeriod, actionPeriod);
        this.maxX = maxX;
        this.minX = minX;
        this.maxY = maxY;
        this.minY = minY;
    }

    @Override
    public void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        this.moveAround(world, scheduler, this.maxX, this.minX, this.maxY, this.minY);
        scheduler.scheduleEvent(this,
                new ActivityAction(this, world, imageStore),
                super.getActionPeriod());
    }

    public void moveAround(WorldModel world, EventScheduler scheduler,
                            int maxX, int minX, int maxY, int minY) {
        Point pos = super.getPosition();
        if (pos.getX() == minX) {
            if (pos.getY() == maxY) moveRight(world, scheduler);
            else moveDown(world, scheduler);
        } else if (pos.getX() == maxX) {
            if (pos.getY() == minY) moveLeft(world, scheduler);
            else moveUp(world, scheduler);
        } else if (pos.getY() == minY) {
            moveLeft(world, scheduler);
        } else if (pos.getY() == maxY) {
            moveRight(world, scheduler);
        } else this.setPosition(new Point (minX, minY));
    }

    private void moveTo(WorldModel world, Point nextPos, EventScheduler scheduler) {
        if (!super.getPosition().equals(nextPos)) {
            Optional<Entity> occupant = world.getOccupant(nextPos);
            if ((world.isOccupied(nextPos)
                        && !(occupant.get() instanceof CoyoteEntity)
                        && !(occupant.get() instanceof CowEntity))
                    || !world.withinBounds(nextPos)) {
                nextPos = super.getPosition();
            }
            if (occupant.isPresent() &&
                    (occupant.get() instanceof CoyoteEntity || occupant.get() instanceof CowEntity)) {
                scheduler.unscheduleAllEvents(occupant.get());
            }
            world.moveEntity(this, nextPos);
        }
    }

    private void moveUp(WorldModel world, EventScheduler scheduler) {
        Point nextPos = new Point(super.getPosition().getX(), super.getPosition().getY() -1);

        moveTo(world, nextPos, scheduler);
    }

    private void moveDown(WorldModel world, EventScheduler scheduler) {
        Point nextPos = new Point(super.getPosition().getX(), super.getPosition().getY() +1);

        moveTo(world, nextPos, scheduler);
    }

    private void moveLeft(WorldModel world, EventScheduler scheduler) {
        Point nextPos = new Point(super.getPosition().getX() -1, super.getPosition().getY());

        moveTo(world, nextPos, scheduler);
    }

    private void moveRight(WorldModel world, EventScheduler scheduler) {
        Point nextPos = new Point(super.getPosition().getX() +1, super.getPosition().getY());

        moveTo(world, nextPos, scheduler);
    }
}
