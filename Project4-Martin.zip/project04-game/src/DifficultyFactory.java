public interface DifficultyFactory extends Factory {

    boolean coyoteSuccess();

    CornEntity createCorn(Point pos);

    CowIdleEntity createCowIdle(Point pos);

    CoyoteEntity createCoyote(Point pos);
}
