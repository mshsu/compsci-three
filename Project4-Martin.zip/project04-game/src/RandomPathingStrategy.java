import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import java.util.function.BiPredicate;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class RandomPathingStrategy
   implements PathingStrategy
{
   private static Random rand = new Random();

   public List<Point> computePath(Point start, Point end,
      Predicate<Point> canPassThrough,
      BiPredicate<Point, Point> withinReach,
      Function<Point, Stream<Point>> potentialNeighbors)
   {
      /* Does not check withinReach.  Since only a single step is taken
       * on each call, the caller will need to check if the destination
       * has been reached.
       */
      List<Point> next = new ArrayList<>();
      List<Point> neighbors = potentialNeighbors.apply(start)
              .filter(canPassThrough)
              .filter(pt -> !Objects.equals(pt, start) && !Objects.equals(pt, end))
              .collect(Collectors.toList());

      if (neighbors.size() == 0) return next;

      int x = rand.nextInt(0,8);
      while (x >= neighbors.size())
         x = rand.nextInt(0, 8);

      next.add(neighbors.get(x));

      return next;
   }
}