import processing.core.PImage;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class DogEntity extends MoveableEntity {
    private static DogEntity dog;

    private DogEntity(String id, Point position, List<PImage> images, int animationPeriod, int actionPeriod) {
        super(id, position, images, animationPeriod, actionPeriod);
        super.setStrategy(new AStarPathingStrategy());
    }

    public static void setDog(String id, Point position, List<PImage> images, int animationPeriod, int actionPeriod) {
        dog = new DogEntity(id, position, images, animationPeriod, actionPeriod);
    }

    public static DogEntity getDog() {
        return dog;
    }

    @Override
    public void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        Optional<Entity> dogTarget =
                world.findNearest(super.getPosition(), new ArrayList<>(Arrays.asList(CoyoteEntity.class)));
        Optional<Entity> dogOwner =
                world.findNearest(super.getPosition(), new ArrayList<>(Arrays.asList(PlayerEntity.class)));

        if (dogTarget.isPresent()) {
            super.setImages(imageStore.getImageList(Parser.DOGHUNT_KEY));
            this.moveTo(world, dogTarget.get(), scheduler);
        } else if (dogOwner.isPresent()) {
            super.setImages(imageStore.getImageList(Parser.DOG_KEY));
            this.moveTo(world, dogOwner.get(), scheduler);
        }
        scheduler.scheduleEvent(this,
                new ActivityAction(this, world, imageStore),
                super.getActionPeriod());
    }

    @Override
    public boolean moveTo(WorldModel world, Entity target, EventScheduler scheduler) {
        if (super.getPosition().adjacent(target.getPosition())) {
            if (target instanceof CoyoteEntity) {
                CoyoteEntity coyote = (CoyoteEntity) target;
                coyote.setHealth(coyote.getHealth() - 1);
                if (coyote.getHealth() <= 0) {
                    world.removeEntity(target);
                    scheduler.unscheduleAllEvents(target);
                }
            }
            return true;
        }
        else {
            Point nextPos = this.nextPosition(world, target.getPosition());

            if (!super.getPosition().equals(nextPos)) {
                world.moveEntity(this, nextPos);
            }
            return false;
        }
    }

    @Override
    public Point nextPosition(WorldModel world, Point destPos) {
        List<Point> points = super.getStrategy().computePath(super.getPosition(), destPos,
                pt -> world.withinBounds(pt) && !world.isOccupied(pt),
                world::adjacent,
                PathingStrategy.DIAGONAL_NEIGHBORS);
        Point newPos;
        if (points.size() == 0) newPos = super.getPosition();
        else newPos = points.get(0);

        return newPos;
    }
}
