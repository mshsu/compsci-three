import processing.core.PImage;
import java.util.List;

public class FenceEntity extends Entity {
    public FenceEntity(String id, Point position, List<PImage> images) {
        super(id, position, images);
    }
}
