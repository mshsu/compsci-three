import processing.core.PImage;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class CowHungryEntity extends CowEntity {

    public CowHungryEntity(String id, Point position, List<PImage> images,
                           int animationPeriod, int actionPeriod, int health, int milk) {
        super(id, position, images, animationPeriod, actionPeriod, health, milk);
        super.setStrategy(new SingleStepPathingStrategy());
    }

    @Override
    public void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        Optional<Entity> cowTarget =
                world.findNearest(super.getPosition(), new ArrayList<>(Arrays.asList(CornEntity.class)));

        if (cowTarget.isPresent()) {
            this.moveTo(world, cowTarget.get(), scheduler);
//            if (world.getBackgroundCell(this.getPosition()).getId().equals("dirt"))
//                world.setBackground(this.getPosition(),
//                        new Background("grass", imageStore.getImageList("grass")));
            scheduler.scheduleEvent(this,
                    new ActivityAction(this, world, imageStore),
                    super.getActionPeriod());
        }
        else {
            transform(world, scheduler, imageStore);
        }
    }

    public void transform(
            WorldModel world,
            EventScheduler scheduler,
            ImageStore imageStore)
    {
        CowIdleEntity miner = ParseFactory.createCowIdle(super.getId(),
                super.getPosition(),
                super.getActionPeriod() + 850,
                super.getAnimationPeriod(),
                imageStore.getImageList(Parser.COWIDLE_KEY),
                super.getHealth(), super.getMilk());
        world.removeEntity(this);
        scheduler.unscheduleAllEvents(this);
        world.addEntity(miner);
        miner.scheduleActions(scheduler, world, imageStore);
    }

    @Override
    public boolean moveTo(WorldModel world, Entity target, EventScheduler scheduler) {
        if (super.getPosition().adjacent(target.getPosition())) {
            if (target instanceof CornEntity) {
                CornEntity corn = (CornEntity) target;
                corn.setHealth(corn.getHealth() - 1);
                if (corn.getHealth() <= 0) {
                    world.removeEntity(target);
                    scheduler.unscheduleAllEvents(target);
                    super.setMilk(super.getMilk() + 1);
                }
            }
            return true;
        }
        else {
            Point nextPos = this.nextPosition(world, target.getPosition());

            if (!super.getPosition().equals(nextPos)) {
                world.moveEntity(this, nextPos);
            }
            return false;
        }
    }
}
