import processing.core.PImage;

import java.util.List;

public class StoreEntity extends ActiveEntity{
    private static int milk = 0;
    private static int cowCost;

    public static int getMilk() {
        return milk;
    }

    public static void setMilk(int milk) {
        StoreEntity.milk = milk;
    }

    public static int getCowCost() {
        return cowCost;
    }

    public static void setCowCost(int cowCost) {
        StoreEntity.cowCost = cowCost;
    }
    public StoreEntity(String id, Point position, List<PImage> images, int animationPeriod, int actionPeriod) {
        super(id, position, images, animationPeriod, actionPeriod);
    }

    @Override
    public void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        if (milk == 0) {
            this.setImages(imageStore.getImageList(Parser.STORE_KEY));
        } else if (milk >= cowCost) {
            this.setImages(imageStore.getImageList("storecanbuy"));
        } else {
            this.setImages(imageStore.getImageList("storehasmilk"));
        }
        scheduler.scheduleEvent(this,
                new ActivityAction(this, world, imageStore),
                super.getActionPeriod());
    }
}
