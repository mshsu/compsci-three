import processing.core.PImage;

import java.util.List;

public abstract class ActiveEntity extends AnimatedEntity{
    private int actionPeriod;

    public ActiveEntity(String id, Point position, List<PImage> images,
                        int animationPeriod, int actionPeriod) {
        super(id, position, images, animationPeriod);
        this.actionPeriod = actionPeriod;
    }

    public int getActionPeriod() {
        return actionPeriod;
    }

    public abstract void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler);

    @Override
    public void scheduleActions(
            EventScheduler scheduler,
            WorldModel world,
            ImageStore imageStore)
    {
        scheduler.scheduleEvent(this,
                new ActivityAction(this, world, imageStore),
                this.actionPeriod);
        scheduler.scheduleEvent(this,
                new AnimationAction(this, 0),
                this.getAnimationPeriod());

    }
}
