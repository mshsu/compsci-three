import java.util.*;
import java.util.function.BiPredicate;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class DijkstraPathingStrategy
    implements PathingStrategy
{
    public class Node {
        private Point point;
        private Point prior;
        private double cost;

        public Node(Point point, Point prior, double cost) {
            this.point = point;
            this.prior = prior;
            this.cost = cost;
        }

        public double getCost() {
            return cost;
        }
    }

    /* Consulted https://www.youtube.com/watch?v=CerlT7tTZfY */
    @Override
    public List<Point> computePath(Point start, Point end,
                                   Predicate<Point> canPassThrough,
                                   BiPredicate<Point, Point> withinReach,
                                   Function<Point, Stream<Point>> potentialNeighbors)
    {
        List<Point> path = new LinkedList<>();
        PriorityQueue<Node> priorityQueue = new PriorityQueue<>(Comparator.comparing(Node::getCost));
        HashMap<Point, Node> visited = new HashMap<>();

        Node current = new Node(start, null, 0);
        visited.put(start, current);
        while (!withinReach.test(current.point, end)) {
            Node finalCurrent = current;
            priorityQueue.addAll(potentialNeighbors.apply(current.point)
                    .filter(canPassThrough)
                    .filter(pt -> !Objects.equals(pt, end) && !Objects.equals(pt, start))
                    .filter(pt -> !visited.containsKey(pt))
                    .map(pt -> new Node(pt, finalCurrent.point,
                            (finalCurrent.cost
                                    //Manhattan Distance
                                    //+ Math.abs(pt.getX() - finalCurrent.point.getX())
                                    //+ Math.abs(pt.getY() - finalCurrent.point.getY())
                                    //Euclidean Distance
                                    + Math.sqrt(Math.pow(pt.getX() - finalCurrent.point.getX(), 2)
                                    + Math.pow(pt.getY() - finalCurrent.point.getY(), 2))
                    )))
                    .collect(Collectors.toList()));

            while (visited.containsKey(current.point)) {
                current = priorityQueue.poll();
                if (current == null) return path;
            }
            visited.put(current.point, current);
        }

        while (current.prior != null) {
            path.add(0, current.point);
            current = visited.get(current.prior);
        }

        return path;
    }
}
