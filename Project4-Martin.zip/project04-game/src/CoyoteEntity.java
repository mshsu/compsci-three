import processing.core.PImage;

import java.util.*;

public class CoyoteEntity extends MoveableEntity{
    private int health;

    public CoyoteEntity(String id, Point position, List<PImage> images,
                        int animationPeriod, int actionPeriod, int health) {
        super(id, position, images, animationPeriod, actionPeriod);
        this.health = health;
        super.setStrategy(new DijkstraPathingStrategy());
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    @Override
    public void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        Optional<Entity> coyoteTarget =
                world.findNearest(super.getPosition(), new ArrayList<>(Arrays.asList(CowEntity.class)));

        if (coyoteTarget.isPresent()) {
            this.moveTo(world, coyoteTarget.get(), scheduler);
            scheduler.scheduleEvent(this,
                    new ActivityAction(this, world, imageStore),
                    super.getActionPeriod());
        } else {
            world.removeEntity(this);
            scheduler.unscheduleAllEvents(this);
        }
    }

    @Override
    public boolean moveTo(WorldModel world, Entity target, EventScheduler scheduler) {
        if (super.getPosition().adjacent(target.getPosition())) {
            if (target instanceof CowEntity) {
                CowEntity cow = (CowEntity) target;
                cow.setHealth(cow.getHealth() - 1);
                if (cow.getHealth() <= 0) {
                    world.removeEntity(target);
                    scheduler.unscheduleAllEvents(target);
                }
            }
            return true;
        }
        else {
            Point nextPos = this.nextPosition(world, target.getPosition());

            if (!super.getPosition().equals(nextPos)) {
                Optional<Entity> occupant = world.getOccupant(nextPos);
                if (occupant.isPresent()) {
                    scheduler.unscheduleAllEvents(occupant.get());
                }
                world.moveEntity(this, nextPos);
            }
            return false;
        }
    }

    @Override
    public Point nextPosition(WorldModel world, Point destPos) {
        List<Point> points = super.getStrategy().computePath(super.getPosition(), destPos,
                pt -> world.withinBounds(pt) && (!world.isOccupied(pt) || world.getOccupant(pt).get() instanceof CornEntity),
                world::adjacent,
                PathingStrategy.DIAGONAL_CARDINAL_NEIGHBORS);
        Point newPos;
        if (points.size() == 0) newPos = super.getPosition();
        else newPos = points.get(0);

        return newPos;
    }
}
