public class AnimationAction implements Action {
    AnimatedEntity entity;
    private int repeatCount;

    public AnimationAction(AnimatedEntity entity, int repeatCount) {
        this.entity = entity;
        this.repeatCount = repeatCount;
    }

    @Override
    public void executeAction(
            EventScheduler scheduler)
    {
        entity.nextImage();

        if (this.repeatCount != 1) {
            scheduler.scheduleEvent(entity,
                    new AnimationAction(entity,
                            Math.max(this.repeatCount - 1,
                                    0)),
                    entity.getAnimationPeriod());
        }
    }
}
