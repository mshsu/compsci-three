import java.util.Random;

public class MediumFactory implements DifficultyFactory {
    private ImageStore imageStore;
    public static final int COYOTE_ACTIONPERIOD= 200;
    public static final int COYOTE_HEALTH = 10;
    public static final int COW_COST = 10;
    public static final int TRIGGER = 10;

    public MediumFactory(ImageStore imageStore) {
        this.imageStore = imageStore;
        StoreEntity.setCowCost(COW_COST);
    }
    public boolean coyoteSuccess() {
        Random rand = new Random();
        int x = rand.nextInt(0, 3);
        return x == 0;
    }

    public CornEntity createCorn(Point pos)
    {
        return new CornEntity("corn_" + pos.getX() +"_"+ pos.getY(), pos,
                imageStore.getImageList("corn"), 5);
    }

    public CowIdleEntity createCowIdle(Point pos)
    {
        Random rand = new Random();
        return new CowIdleEntity("cow_" + pos.getX() +"_"+ pos.getY(), pos,
                imageStore.getImageList("cowidle"),
                1000, rand.nextInt(1000, 1200), 20, 0);
    }

    public CoyoteEntity createCoyote(Point pos)
    {
        return new CoyoteEntity("coyote_" + pos.getX() +"_"+ pos.getY(), pos,
                imageStore.getImageList("coyote"), 10, COYOTE_ACTIONPERIOD, COYOTE_HEALTH);
    }
}
