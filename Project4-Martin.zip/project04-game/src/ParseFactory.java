import processing.core.PImage;
import java.util.List;

public class ParseFactory implements Factory{

    public static WaterEntity createWater(
            String id, Point position, int animationPeriod, List<PImage> images)
    {
        return new WaterEntity(id, position, images, animationPeriod);
    }

    public static CornEntity createCorn(
            String id, Point position,
            int health,
            List<PImage> images)
    {
        return new CornEntity(id, position, images, health);
    }

    public static FenceEntity createFence(
            String id, Point position,
            List<PImage> images)
    {
        return new FenceEntity(id, position, images);
    }

    public static ShrubEntity createShrub(
            String id, Point position,
            List<PImage> images)
    {
        return new ShrubEntity(id, position, images);
    }

    public static CarEntity createCar(
            String id, List<PImage> images, int animationPeriod, int actionPeriod,
            int maxX, int minX, int maxY, int minY)
    {
        return new CarEntity(id, images, animationPeriod, actionPeriod, maxX, minX, maxY, minY);
    }

    public static CowIdleEntity createCowIdle(
            String id, Point position,
            int actionPeriod,
            int animationPeriod,
            List<PImage> images,
            int health, int milk)
    {
        return new CowIdleEntity(id, position, images, animationPeriod, actionPeriod, health, milk);
    }

    public static CowHungryEntity createCowHungry(
            String id, Point position,
            int actionPeriod,
            int animationPeriod,
            List<PImage> images,
            int health, int milk)
    {
        return new CowHungryEntity(id, position, images, animationPeriod, actionPeriod, health, milk);
    }

    public static CoyoteEntity createCoyote(
            String id, Point position,
            int actionPeriod,
            int animationPeriod,
            List<PImage> images,
            int health)
    {
        return new CoyoteEntity(id, position, images, animationPeriod, actionPeriod, health);
    }

    public static PlayerEntity createPlayer(
            String id, Point position, int animationPeriod, int actionPeriod, List<PImage> images)
    {
        PlayerEntity.setPlayer(id, position, images, animationPeriod, actionPeriod);
        return PlayerEntity.getPlayer();
    }

    public static DogEntity createDog(
            String id, Point position, List<PImage> images, int animationPeriod, int actionPeriod)
    {
        DogEntity.setDog(id, position, images, animationPeriod, actionPeriod);
        return DogEntity.getDog();
    }

    public static StoreEntity createStore(
            String id, Point position, List<PImage> images, int animationPeriod, int actionPeriod)
    {
        return new StoreEntity(id, position, images, animationPeriod, actionPeriod);
    }
}
