import processing.core.PImage;
import java.util.List;

public class CornEntity extends Entity {

    private int health;

    public CornEntity(String id, Point position, List<PImage> images, int health) {
        super(id, position, images);
        this.health = health;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }
}
