public class Parser {
    public static final int PROPERTY_KEY = 0;

    public static final String BGND_KEY = "background";
    public static final int BGND_NUM_PROPERTIES = 4;
    public static final int BGND_ID = 1;
    public static final int BGND_COL = 2;
    public static final int BGND_ROW = 3;

    public static final String WATER_KEY = "obstacle";
    public static final int WATER_NUM_PROPERTIES = 5;
    public static final int WATER_ID = 1;
    public static final int WATER_COL = 2;
    public static final int WATER_ROW = 3;
    public static final int WATER_ANIMATION_PERIOD = 4;

    public static final String PLAYER_KEY = "player";
    public static final String PLAYERMILK_KEY = "playermilk";
    public static final String PLAYERFULL_KEY = "playerfull";
    public static final int PLAYER_NUM_PROPERTIES = 6;
    public static final int PLAYER_ID = 1;
    public static final int PLAYER_COL = 2;
    public static final int PLAYER_ROW = 3;
    public static final int PLAYER_ANIMATION_PERIOD = 4;
    public static final int PLAYER_ACTION_PERIOD = 5;

    public static final String COWIDLE_KEY = "cowidle";
    public static final int COWIDLE_NUM_PROPERTIES = 7;
    public static final int COWIDLE_ID = 1;
    public static final int COWIDLE_COL = 2;
    public static final int COWIDLE_ROW = 3;
    public static final int COWIDLE_ANIMATION_PERIOD = 4;
    public static final int COWIDLE_ACTION_PERIOD = 5;
    public static final int COWIDLE_HEALTH = 6;

    public static final String COWHUNGRY_KEY = "cowhungry";
    public static final int COWHUNGRY_NUM_PROPERTIES = 7;
    public static final int COWHUNGRY_ID = 1;
    public static final int COWHUNGRY_COL = 2;
    public static final int COWHUNGRY_ROW = 3;
    public static final int COWHUNGRY_ANIMATION_PERIOD = 4;
    public static final int COWHUNGRY_ACTION_PERIOD = 5;
    public static final int COWHUNGRY_HEALTH = 6;

    public static final String COWMILK_KEY = "cowmilk";
    public static final String COWBLINK_KEY = "cowblink";

    public static final String DOG_KEY = "dog";
    public static final String DOGHUNT_KEY = "doghunt";
    public static final int DOG_NUM_PROPERTIES = 6;
    public static final int DOG_ID = 1;
    public static final int DOG_COL = 2;
    public static final int DOG_ROW = 3;
    public static final int DOG_ANIMATION_PERIOD = 4;
    public static final int DOG_ACTION_PERIOD = 5;

    public static final String STORE_KEY = "store";
    public static final int STORE_NUM_PROPERTIES = 6;
    public static final int STORE_ID = 1;
    public static final int STORE_COL = 2;
    public static final int STORE_ROW = 3;
    public static final int STORE_ANIMATION_PERIOD = 4;
    public static final int STORE_ACTION_PERIOD = 5;

    public static final String COYOTE_KEY = "coyote";
    public static final int COYOTE_NUM_PROPERTIES = 7;
    public static final int COYOTE_ID = 1;
    public static final int COYOTE_COL = 2;
    public static final int COYOTE_ROW = 3;
    public static final int COYOTE_ANIMATION_PERIOD = 4;
    public static final int COYOTE_ACTION_PERIOD = 5;
    public static final int COYOTE_HEALTH = 6;

    public static final String CAR_KEY = "car";
    public static final int CAR_NUM_PROPERTIES = 8;
    public static final int CAR_ID = 1;
    public static final int CAR_MINX = 2;
    public static final int CAR_MINY = 3;
    public static final int CAR_ANIMATION_PERIOD = 4;
    public static final int CAR_ACTION_PERIOD = 5;
    public static final int CAR_MAXX = 6;
    public static final int CAR_MAXY = 7;

    public static final String FENCE_KEY = "fence";
    public static final int FENCE_NUM_PROPERTIES = 4;
    public static final int FENCE_ID = 1;
    public static final int FENCE_COL = 2;
    public static final int FENCE_ROW = 3;

    public static final String SHRUB_KEY = "shrub";
    public static final int SHRUB_NUM_PROPERTIES = 4;
    public static final int SHRUB_ID = 1;
    public static final int SHRUB_COL = 2;
    public static final int SHRUB_ROW = 3;

    public static final String CORN_KEY = "corn";
    public static final int CORN_NUM_PROPERTIES = 6;
    public static final int CORN_ID = 1;
    public static final int CORN_COL = 2;
    public static final int CORN_ROW = 3;
    public static final int CORN_HEALTH = 4;

    public static boolean processLine(
            String line, WorldModel world, ImageStore imageStore)
    {
        String[] properties = line.split("\\s");
        if (properties.length > 0) {
            switch (properties[PROPERTY_KEY]) {
                case BGND_KEY:
                    return parseBackground(properties, world, imageStore);
                case WATER_KEY:
                    return parseWater(properties, world, imageStore);
                case PLAYER_KEY:
                    return parsePlayer(properties, world, imageStore);
                case COWIDLE_KEY:
                    return parseCow(properties, world, imageStore);
                case DOG_KEY:
                    return parseDog(properties, world, imageStore);
                case CORN_KEY:
                    return parseCorn(properties, world, imageStore);
                case COWHUNGRY_KEY:
                    return parseCowHungry(properties, world, imageStore);
                case COYOTE_KEY:
                    return parseCoyote(properties, world, imageStore);
                case FENCE_KEY:
                    return parseFence(properties, world, imageStore);
                case CAR_KEY:
                    return parseCar(properties, world, imageStore);
                case STORE_KEY:
                    return parseStore(properties, world, imageStore);
                case SHRUB_KEY:
                    return parseShrub(properties, world, imageStore);
            }
        }

        return false;
    }

    private static boolean parseBackground(
            String[] properties, WorldModel world, ImageStore imageStore)
    {
        if (properties.length == BGND_NUM_PROPERTIES) {
            Point pt = new Point(Integer.parseInt(properties[BGND_COL]),
                    Integer.parseInt(properties[BGND_ROW]));
            String id = properties[BGND_ID];
            world.setBackground(pt,
                    new Background(id, imageStore.getImageList(id)));
        }

        return properties.length == BGND_NUM_PROPERTIES;
    }

    private static boolean parseCow(
            String[] properties, WorldModel world, ImageStore imageStore)
    {
        if (properties.length == COWIDLE_NUM_PROPERTIES) {
            Point pt = new Point(Integer.parseInt(properties[COWIDLE_COL]),
                    Integer.parseInt(properties[COWIDLE_ROW]));
            CowIdleEntity entity = ParseFactory.createCowIdle(properties[COWIDLE_ID], pt,
                    Integer.parseInt(properties[COWIDLE_ACTION_PERIOD]),
                    Integer.parseInt(properties[COWIDLE_ANIMATION_PERIOD]),
                    imageStore.getImageList(COWIDLE_KEY),
                    Integer.parseInt(properties[COWIDLE_HEALTH]), 0);
            world.tryAddEntity(entity);
        }

        return properties.length == COWIDLE_NUM_PROPERTIES;
    }

    private static boolean parseCowHungry(
            String[] properties, WorldModel world, ImageStore imageStore)
    {
        if (properties.length == COWHUNGRY_NUM_PROPERTIES) {
            Point pt = new Point(Integer.parseInt(properties[COWHUNGRY_COL]),
                    Integer.parseInt(properties[COWHUNGRY_ROW]));
            CowHungryEntity entity = ParseFactory.createCowHungry(properties[COWHUNGRY_ID], pt,
                    Integer.parseInt(properties[COWHUNGRY_ACTION_PERIOD]),
                    Integer.parseInt(properties[COWHUNGRY_ANIMATION_PERIOD]),
                    imageStore.getImageList(COWHUNGRY_KEY),
                    Integer.parseInt(properties[COWHUNGRY_HEALTH]), 0);
            world.tryAddEntity(entity);
        }

        return properties.length == COWHUNGRY_NUM_PROPERTIES;
    }

    private static boolean parseCorn(
            String[] properties, WorldModel world, ImageStore imageStore)
    {
        if (properties.length == CORN_NUM_PROPERTIES) {
            Point pt = new Point(Integer.parseInt(properties[CORN_COL]),
                    Integer.parseInt(properties[CORN_ROW]));
            CornEntity entity = ParseFactory.createCorn(properties[CORN_ID], pt,
                    Integer.parseInt(properties[CORN_HEALTH]),
                    imageStore.getImageList(CORN_KEY));
            world.tryAddEntity(entity);
        }

        return properties.length == CORN_NUM_PROPERTIES;
    }

    private static boolean parseFence(
            String[] properties, WorldModel world, ImageStore imageStore)
    {
        if (properties.length == FENCE_NUM_PROPERTIES) {
            Point pt = new Point(Integer.parseInt(properties[FENCE_COL]),
                    Integer.parseInt(properties[FENCE_ROW]));
            FenceEntity entity = ParseFactory.createFence(properties[FENCE_ID], pt,
                    imageStore.getImageList(FENCE_KEY));
            world.tryAddEntity(entity);
        }

        return properties.length == FENCE_NUM_PROPERTIES;
    }

    private static boolean parseShrub(
            String[] properties, WorldModel world, ImageStore imageStore)
    {
        if (properties.length == SHRUB_NUM_PROPERTIES) {
            Point pt = new Point(Integer.parseInt(properties[SHRUB_COL]),
                    Integer.parseInt(properties[SHRUB_ROW]));
            ShrubEntity entity = ParseFactory.createShrub(properties[SHRUB_ID], pt,
                    imageStore.getImageList(SHRUB_KEY));
            world.tryAddEntity(entity);
        }

        return properties.length == SHRUB_NUM_PROPERTIES;
    }

    private static boolean parseWater(
            String[] properties, WorldModel world, ImageStore imageStore)
    {
        if (properties.length == WATER_NUM_PROPERTIES) {
            Point pt = new Point(Integer.parseInt(properties[WATER_COL]),
                    Integer.parseInt(properties[WATER_ROW]));
            WaterEntity entity = ParseFactory.createWater(properties[WATER_ID], pt,
                    Integer.parseInt(properties[WATER_ANIMATION_PERIOD]),
                    imageStore.getImageList(
                            WATER_KEY));
            world.tryAddEntity(entity);
        }

        return properties.length == WATER_NUM_PROPERTIES;
    }

    private static boolean parsePlayer(
            String[] properties, WorldModel world, ImageStore imageStore)
    {
        if (properties.length == PLAYER_NUM_PROPERTIES) {
            Point pt = new Point(Integer.parseInt(properties[PLAYER_COL]),
                    Integer.parseInt(properties[PLAYER_ROW]));
            PlayerEntity entity = ParseFactory.createPlayer(properties[PLAYER_ID], pt,
                    Integer.parseInt(properties[PLAYER_ANIMATION_PERIOD]),
                    Integer.parseInt(properties[PLAYER_ACTION_PERIOD]),
                    imageStore.getImageList(
                            PLAYER_KEY));
            world.tryAddEntity(entity);
        }

        return properties.length == PLAYER_NUM_PROPERTIES;
    }

    private static boolean parseDog(
            String[] properties, WorldModel world, ImageStore imageStore)
    {
        if (properties.length == DOG_NUM_PROPERTIES) {
            Point pt = new Point(Integer.parseInt(properties[DOG_COL]),
                    Integer.parseInt(properties[DOG_ROW]));
            DogEntity entity = ParseFactory.createDog(properties[DOG_ID], pt,
                    imageStore.getImageList(DOG_KEY),
                    Integer.parseInt(properties[DOG_ANIMATION_PERIOD]),
                    Integer.parseInt(properties[DOG_ACTION_PERIOD]));
            world.tryAddEntity(entity);
        }

        return properties.length == DOG_NUM_PROPERTIES;
    }

    private static boolean parseStore(
            String[] properties, WorldModel world, ImageStore imageStore)
    {
        if (properties.length == STORE_NUM_PROPERTIES) {
            Point pt = new Point(Integer.parseInt(properties[STORE_COL]),
                    Integer.parseInt(properties[STORE_ROW]));
            StoreEntity entity = ParseFactory.createStore(properties[STORE_ID], pt,
                    imageStore.getImageList(STORE_KEY),
                    Integer.parseInt(properties[STORE_ANIMATION_PERIOD]),
                    Integer.parseInt(properties[STORE_ACTION_PERIOD]));
            world.tryAddEntity(entity);
        }

        return properties.length == STORE_NUM_PROPERTIES;
    }

    private static boolean parseCoyote(
            String[] properties, WorldModel world, ImageStore imageStore)
    {
        if (properties.length == COYOTE_NUM_PROPERTIES) {
            Point pt = new Point(Integer.parseInt(properties[COYOTE_COL]),
                    Integer.parseInt(properties[COYOTE_ROW]));
            CoyoteEntity entity = ParseFactory.createCoyote(properties[COYOTE_ID], pt,
                    Integer.parseInt(properties[COYOTE_ACTION_PERIOD]),
                    Integer.parseInt(properties[COYOTE_ANIMATION_PERIOD]),
                    imageStore.getImageList(COYOTE_KEY),
                    Integer.parseInt(properties[COYOTE_HEALTH]));
            world.tryAddEntity(entity);
        }

        return properties.length == COYOTE_NUM_PROPERTIES;
    }

    private static boolean parseCar(
            String[] properties, WorldModel world, ImageStore imageStore)
    {
        if (properties.length == CAR_NUM_PROPERTIES) {
            CarEntity entity = ParseFactory.createCar(properties[CAR_ID],
                    imageStore.getImageList(CAR_KEY),
                    Integer.parseInt(properties[CAR_ANIMATION_PERIOD]),
                    Integer.parseInt(properties[CAR_ACTION_PERIOD]),
                    Integer.parseInt(properties[CAR_MAXX]),
                    Integer.parseInt(properties[CAR_MINX]),
                    Integer.parseInt(properties[CAR_MAXY]),
                    Integer.parseInt(properties[CAR_MINY]));
            world.tryAddEntity(entity);
        }

        return properties.length == CAR_NUM_PROPERTIES;
    }
}
