import processing.core.PImage;

import java.util.List;
import java.util.Optional;

public class PlayerEntity extends ActiveEntity{

    private static PlayerEntity player;
    public static final int MILK_LIMIT = 10;
    private int milk = 0;
    private int cows = 0;

    private PlayerEntity(String id, Point position, List<PImage> images, int animationPeriod, int actionPeriod) {
        super(id, position, images, animationPeriod, actionPeriod);
    }

    public int getMilk() {
        return milk;
    }

    public int getCows() {
        return cows;
    }

    public void setCows(int cows) {
        this.cows = cows;
    }

    public static PlayerEntity getPlayer() {
        return player;
    }

    public static void setPlayer(String id, Point position, List<PImage> images,
                                 int animationPeriod, int actionPeriod) {
        player = new PlayerEntity(id, position, images, animationPeriod, actionPeriod);
    }

    @Override
    public void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        if (milk == 0) {
            player.setImages(imageStore.getImageList(Parser.PLAYER_KEY));
        } else if (milk >= MILK_LIMIT) {
            player.setImages(imageStore.getImageList(Parser.PLAYERFULL_KEY));
        } else {
            player.setImages(imageStore.getImageList(Parser.PLAYERMILK_KEY));
        }
        scheduler.scheduleEvent(this,
                new ActivityAction(this, world, imageStore),
                super.getActionPeriod());
    }

    private void moveTo(WorldModel world, Point nextPos, EventScheduler scheduler) {
        if (!super.getPosition().equals(nextPos)) {
            Optional<Entity> occupant = world.getOccupant(nextPos);
            if ((world.isOccupied(nextPos) && !(occupant.get() instanceof CoyoteEntity))
                    || !world.withinBounds(nextPos)) {
                nextPos = super.getPosition();
            }
            if (occupant.isPresent() && occupant.get() instanceof CoyoteEntity) {
                scheduler.unscheduleAllEvents(occupant.get());
            }
            if (occupant.isPresent() && occupant.get() instanceof CowIdleEntity) {
                CowIdleEntity cow = (CowIdleEntity) occupant.get();
                if (cow.getMilk() > 0 && this.milk < MILK_LIMIT) {
                    cow.setMilk(cow.getMilk() - 1);
                    this.milk++;
                }
            }
            if (occupant.isPresent() && occupant.get() instanceof StoreEntity) {
                StoreEntity.setMilk(StoreEntity.getMilk() + this.milk);
                this.milk = 0;
                this.cows = StoreEntity.getMilk() / StoreEntity.getCowCost();
            }
            world.moveEntity(this, nextPos);
        }
    }

    public void moveUp(WorldModel world, EventScheduler scheduler) {
        Point nextPos = new Point(super.getPosition().getX(), super.getPosition().getY() -1);

        moveTo(world, nextPos, scheduler);
    }

    public void moveDown(WorldModel world, EventScheduler scheduler) {
        Point nextPos = new Point(super.getPosition().getX(), super.getPosition().getY() +1);

        moveTo(world, nextPos, scheduler);
    }

    public void moveLeft(WorldModel world, EventScheduler scheduler) {
        Point nextPos = new Point(super.getPosition().getX() -1, super.getPosition().getY());

        moveTo(world, nextPos, scheduler);
    }

    public void moveRight(WorldModel world, EventScheduler scheduler) {
        Point nextPos = new Point(super.getPosition().getX() +1, super.getPosition().getY());

        moveTo(world, nextPos, scheduler);
    }
}
