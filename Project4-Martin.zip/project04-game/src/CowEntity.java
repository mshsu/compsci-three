import processing.core.PImage;
import java.util.List;

public abstract class CowEntity extends MoveableEntity {

    private int health;
    private int milk;

    public CowEntity(String id, Point position, List<PImage> images,
                     int animationPeriod, int actionPeriod, int health, int milk) {
        super(id, position, images, animationPeriod, actionPeriod);
        this.health = health;
        this.milk = milk;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public int getMilk() {
        return milk;
    }

    public void setMilk(int milk) {
        this.milk = milk;
    }

    public abstract void transform(WorldModel world, EventScheduler scheduler, ImageStore imageStore);

    @Override
    public Point nextPosition(WorldModel world, Point destPos) {
        List<Point> points = super.getStrategy().computePath(super.getPosition(), destPos,
                pt -> world.withinBounds(pt) && !world.isOccupied(pt),
                world::adjacent,
                PathingStrategy.CARDINAL_NEIGHBORS);
        Point newPos;
        if (points.size() == 0) newPos = super.getPosition();
        else newPos = points.get(0);

        return newPos;
    }
}
