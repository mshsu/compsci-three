import processing.core.PImage;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class CowIdleEntity extends CowEntity {

    public CowIdleEntity(String id, Point position, List<PImage> images,
                         int animationPeriod, int actionPeriod, int health, int milk) {
        super(id, position, images, animationPeriod, actionPeriod, health, milk);
        super.setStrategy(new RandomPathingStrategy());
    }

    @Override
    public void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        Optional<Entity> cowTarget =
                world.findNearest(super.getPosition(), new ArrayList<>(Arrays.asList(PlayerEntity.class)));
        Optional<Entity> corn =
                world.findNearest(super.getPosition(), new ArrayList<>(Arrays.asList(CornEntity.class)));

        if (super.getMilk() > 0) super.setImages(imageStore.getImageList(Parser.COWBLINK_KEY));
        else super.setImages(imageStore.getImageList(Parser.COWIDLE_KEY));

        if (corn.isPresent())
            transform(world, scheduler, imageStore);
        else if (cowTarget.isPresent()) {
            if(this.moveTo(world, cowTarget.get(), scheduler)) {
                PlayerEntity player = PlayerEntity.getPlayer();
                if (player.getMilk() < PlayerEntity.MILK_LIMIT && super.getMilk() > 0)
                    super.setImages(imageStore.getImageList(Parser.COWMILK_KEY));
            }
//            if (world.getBackgroundCell(this.getPosition()).getId().equals("dirt"))
//                world.setBackground(this.getPosition(),
//                        new Background("grass", imageStore.getImageList("grass")));
            scheduler.scheduleEvent(this,
                    new ActivityAction(this, world, imageStore),
                    super.getActionPeriod());
        }
    }

    public void transform(
            WorldModel world,
            EventScheduler scheduler,
            ImageStore imageStore)
    {
        CowHungryEntity miner = ParseFactory.createCowHungry(super.getId(),
                super.getPosition(),
                super.getActionPeriod() - 850,
                super.getAnimationPeriod(),
                imageStore.getImageList(Parser.COWHUNGRY_KEY),
                super.getHealth(), super.getMilk());
         world.removeEntity(this);
         scheduler.unscheduleAllEvents(this);
         world.addEntity(miner);
         miner.scheduleActions(scheduler, world, imageStore);
    }

    @Override
    public boolean moveTo(WorldModel world, Entity target, EventScheduler scheduler) {
        if (super.getPosition().adjacent(target.getPosition())) {
            return true;
        }
        else {
            Point nextPos = this.nextPosition(world, target.getPosition());

            if (!super.getPosition().equals(nextPos)) {
                world.moveEntity(this, nextPos);
            }
            return false;
        }
    }
}
