import org.junit.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestCases {

    @Test
    public void testExpEquals1() {
        LinkedInt left = LinkedInt.toLinkedInt("321");
        LinkedInt right = LinkedInt.toLinkedInt("456");

        Expression exp = new Expression(left, right, '+');

        assertTrue(exp.equals(exp));
    }

    @Test
    public void testExpEquals2() {
        LinkedInt left = LinkedInt.toLinkedInt("321");
        LinkedInt right = LinkedInt.toLinkedInt("456");

        Expression exp1 = new Expression(left, right, '+');
        Expression exp2 = new Expression(left, right, '+');

        assertTrue(exp1.equals(exp2));
    }

    @Test
    public void testExpEquals3() {
        LinkedInt left = LinkedInt.toLinkedInt("321");
        LinkedInt right = LinkedInt.toLinkedInt("456");

        Expression exp1 = new Expression(left, right, '+');
        Expression exp2 = null;

        assertFalse(exp1.equals(exp2));
    }

    @Test
    public void testExpEquals4() {
        LinkedInt left = LinkedInt.toLinkedInt("321");
        LinkedInt right = LinkedInt.toLinkedInt("456");

        Expression exp1 = new Expression(left, right, '+');
        String exp2 = "NOT AN EXPRESSION";

        assertFalse(exp1.equals(exp2));
    }

    @Test
    public void testExpEquals5() {
        LinkedInt left = LinkedInt.toLinkedInt("321");
        LinkedInt right = LinkedInt.toLinkedInt("456");

        Expression exp1 = new Expression(left, right, '+');
        Expression exp2 = new Expression(right, left, '*');

        assertFalse(exp1.equals(exp2));
    }

    @Test
    public void testExpEquals6() {
        LinkedInt left = LinkedInt.toLinkedInt("321");
        LinkedInt right = LinkedInt.toLinkedInt("456");

        Expression exp1 = new Expression(left, right, '+');
        Expression exp2 = new Expression(right, left, '+');

        assertFalse(exp1.equals(exp2));
    }

    @Test
    public void testExpEquals7() {
        LinkedInt left = LinkedInt.toLinkedInt("321");
        LinkedInt right = LinkedInt.toLinkedInt("456");

        Expression exp1 = new Expression(left, right, '+');
        Expression exp2 = new Expression(left, left, '+');

        assertFalse(exp1.equals(exp2));
    }

    /*
    NOTE: Added this test case for full branch coverage after changes were made.
     */
    @Test
    public void testExpToString() {
        LinkedInt left = LinkedInt.toLinkedInt("321");
        LinkedInt right = LinkedInt.toLinkedInt("456");

        Expression exp1 = new Expression(left, right, '+');
        String expected = "321 + 456";

        assertTrue(exp1.toString().equals(expected));
    }

    @Test
    public void testSum() {
        LinkedInt left = LinkedInt.toLinkedInt("321");
        LinkedInt right = LinkedInt.toLinkedInt("456");

        LinkedInt expected = LinkedInt.toLinkedInt("777");

        Expression exp = new Expression(left, right, '+');
        LinkedInt actual = exp.sum();

        assertEquals(expected, actual);
    }

    @Test
    public void testMult() {
        LinkedInt left = LinkedInt.toLinkedInt("321");
        LinkedInt right = LinkedInt.toLinkedInt("456");

        LinkedInt expected = LinkedInt.toLinkedInt("146376");

        Expression exp = new Expression(left, right, '*');
        LinkedInt actual = exp.mult();

        assertEquals(expected, actual);
    }

    @Test
    public void testExp() {
        LinkedInt left = LinkedInt.toLinkedInt("3");
        LinkedInt right = LinkedInt.toLinkedInt("17");

        LinkedInt expected = LinkedInt.toLinkedInt("129140163");

        Expression exp = new Expression(left, right, '^');
        LinkedInt actual = exp.exp();

        assertEquals(expected, actual);
    }

    @Test
    public void testEval1() {
        LinkedInt left = LinkedInt.toLinkedInt("321");
        LinkedInt right = LinkedInt.toLinkedInt("456");

        LinkedInt expected = LinkedInt.toLinkedInt("777");

        Expression exp = new Expression(left, right, '+');
        LinkedInt actual = exp.eval();

        assertEquals(expected, actual);
    }

    @Test
    public void testEval2() {
        LinkedInt left = LinkedInt.toLinkedInt("321");
        LinkedInt right = LinkedInt.toLinkedInt("456");

        LinkedInt expected = LinkedInt.toLinkedInt("146376");

        Expression exp = new Expression(left, right, '*');
        LinkedInt actual = exp.eval();

        assertEquals(expected, actual);
    }

    @Test
    public void testEval3() {
        LinkedInt left = LinkedInt.toLinkedInt("3");
        LinkedInt right = LinkedInt.toLinkedInt("17");

        LinkedInt expected = LinkedInt.toLinkedInt("129140163");

        Expression exp = new Expression(left, right, '^');
        LinkedInt actual = exp.eval();

        assertEquals(expected, actual);
    }

    @Test
    public void testEval4() {
        LinkedInt left = LinkedInt.toLinkedInt("3");
        LinkedInt right = LinkedInt.toLinkedInt("17");

        LinkedInt expected = null;

        Expression exp = new Expression(left, right, '/');
        LinkedInt actual = exp.eval();

        assertEquals(expected, actual);
    }

    @Test
    public void testExpRawToString() {
        String expected = "321 + 456";

        ExpressionRaw expRaw = new ExpressionRaw("321", "456", "+");
        String actual = expRaw.toString();

        assertEquals(expected, actual);
    }

    @Test
    public void testToExpression() {
        LinkedInt left = LinkedInt.toLinkedInt("321");
        LinkedInt right = LinkedInt.toLinkedInt("456");

        Expression expected = new Expression(left, right, '+');

        ExpressionRaw expRaw = new ExpressionRaw("321", "456", "+");
        Expression actual = expRaw.toExpression();

        assertEquals(expected, actual);
    }

    @Test
    public void testExpRawEquals1() {
        ExpressionRaw expRaw = new ExpressionRaw("1", "2", "+");

        assertTrue(expRaw.equals(expRaw));
    }

    @Test
    public void testExpRawEquals2() {
        ExpressionRaw expRaw1 = new ExpressionRaw("1", "2", "+");
        ExpressionRaw expRaw2 = null;

        assertFalse(expRaw1.equals(expRaw2));
    }

    @Test
    public void testExpRawEquals3() {
        ExpressionRaw expRaw1 = new ExpressionRaw("1", "2", "+");
        String expRaw2 = "NOT AN EXPRESSIONRAW";

        assertFalse(expRaw1.equals(expRaw2));
    }

    @Test
    public void testExpRawEquals4() {
        ExpressionRaw expRaw1 = new ExpressionRaw("1", "2", "+");
        ExpressionRaw expRaw2 = new ExpressionRaw("2", "1", "+");

        assertFalse(expRaw1.equals(expRaw2));
    }

    @Test
    public void testExpRawEquals5() {
        ExpressionRaw expRaw1 = new ExpressionRaw("1", "2", "+");
        ExpressionRaw expRaw2 = new ExpressionRaw("1", "2", "*");

        assertFalse(expRaw1.equals(expRaw2));
    }

    @Test
    public void testExpRawEquals6() {
        ExpressionRaw expRaw1 = new ExpressionRaw("1", "2", "+");
        ExpressionRaw expRaw2 = new ExpressionRaw("1", "1", "+");

        assertFalse(expRaw1.equals(expRaw2));
    }

    @Test
    public void testExpRawEquals7() {
        ExpressionRaw expRaw1 = new ExpressionRaw("1", "2", "+");
        ExpressionRaw expRaw2 = new ExpressionRaw("1", "2", "+");

        assertTrue(expRaw1.equals(expRaw2));
    }

    @Test
    public void testLinkIntToString() {
        Node head = new Node(3, new Node(2, new Node(1)));
        LinkedInt link = new LinkedInt(head);
        String actual = link.toString();

        String expected = "123";

        assertEquals(expected, actual);
    }

    @Test
    public void testLinkIntEquals1() {
        Node head = new Node(3, new Node(2, new Node(1)));
        LinkedInt link1 = new LinkedInt(head);
        LinkedInt link2 = null;

        assertFalse(link1.equals(link2));
    }

    @Test
    public void testLinkIntEquals2() {
        Node head = new Node(3, new Node(2, new Node(1)));
        LinkedInt link1 = new LinkedInt(head);
        String link2 = "NOT A LINKEDINT";

        assertFalse(link1.equals(link2));
    }

    /*
    NOTE: Added this test case for full branch coverage after changes were made.
     */
    @Test
    public void testLinkIntEquals3() {
        Node head = new Node(3, new Node(2, new Node(1)));
        LinkedInt link1 = new LinkedInt(head);

        assertTrue(link1.equals(link1));
    }

    @Test
    public void testGetHead() {
        LinkedInt link = new LinkedInt(new Node(7));
        Node expected = new Node(7);

        assertEquals(expected, link.getHead());
    }

    @Test
    public void testToLinkedInt1() {
        String s = "1425";
        LinkedInt actual = LinkedInt.toLinkedInt(s);

        Node head = new Node(5, new Node(2, new Node(4, new Node(1))));
        LinkedInt expected = new LinkedInt(head);

        assertEquals(expected, actual);
    }

    @Test
    public void testToLinkedInt2() {
        String s = "00000000012";
        LinkedInt actual = LinkedInt.toLinkedInt(s);

        Node head = new Node(2, new Node(1));
        LinkedInt expected = new LinkedInt(head);

        assertEquals(expected, actual);
    }

    @Test
    public void testToLinkedInt3() {
        String s = "0000000000";
        LinkedInt actual = LinkedInt.toLinkedInt(s);

        Node head = new Node(0);
        LinkedInt expected = new LinkedInt(head);

        assertEquals(expected, actual);
    }

    @Test
    public void testSumNode() {
        Node node1 = new Node(8);
        Node node2 = new Node(7);

        Node expected = new Node(5, new Node(1));
        Node actual = node1.sumNode(node2, 0);

        assertEquals(expected, actual);
    }

    @Test
    public void testMultNodeHelper() {
        Node node = new Node(1, new Node(2, new Node(3)));
        Node expected = new Node(2, new Node(4, new Node(6)));
        Node actual = node.multNodeHelper(2, 0);

        assertEquals(expected, actual);
    }

    @Test
    public void testMultNode() {
        Node node1 = new Node(8);
        Node node2 = new Node(7);

        Node expected = new Node(6, new Node(5));
        Node actual = node1.multNode(node2);

        assertEquals(expected, actual);
    }

    @Test
    public void testDivNodeByTwo() {
        Node node = new Node(2, new Node(2));

        Node expected = new Node(1, new Node(1));
        Node actual = node.divNodeByTwo();

        assertEquals(expected, actual);
    }

    @Test
    public void testExpNode() {
        Node exp = new Node(0);
        Node base = new Node(5, new Node(4));

        Node expected = new Node(1);
        Node actual = base.expNode(exp);

        assertEquals(expected, actual);
    }

    @Test
    public void testNodeToString() {
        Node node = new Node(1, new Node(2, new Node(3)));
        String expected = "321";
        String actual = node.toString();

        assertEquals(expected, actual);
    }

    @Test
    public void testNodeEquals1() {
        Node node1 = new Node(1, new Node(2, new Node(3)));

        assertTrue(node1.equals(node1));
    }

    @Test
    public void testNodeEquals2() {
        Node node1 = new Node(1, new Node(2, new Node(3)));
        Node node2 = null;

        assertFalse(node1.equals(node2));
    }

    @Test
    public void testNodeEquals3() {
        Node node1 = new Node(1, new Node(2, new Node(3)));
        String node2 = "NOT A NODE";

        assertFalse(node1.equals(node2));
    }

    @Test
    public void testNodeEquals4() {
        Node node1 = new Node(1, new Node(2, new Node(3)));
        Node node2 = new Node(1, new Node(2));

        assertFalse(node1.equals(node2));
    }

    @Test
    public void testNodeEquals5() {
        Node node1 = new Node(1, new Node(2));
        Node node2 = new Node(1, new Node(2, new Node(3)));

        assertFalse(node1.equals(node2));
    }

    @Test
    public void testGetValue() {
        Node node = new Node(1, new Node(2, new Node(3)));
        int expected = 1;

        assertEquals(expected, node.getValue());
    }

    @Test
    public void testGetNext() {
        Node node = new Node(1, new Node(2, new Node(3)));
        Node expected = new Node(2, new Node(3));

        assertEquals(expected, node.getNext());
    }

    @Test
    public void testCleanNode() {
        Node unclean = new Node(1, new Node(0, new Node(0)));

        Node expected = new Node(1, new Node(0));
        Node actual = unclean.cleanNode();

        assertEquals(expected, actual);
    }
}
