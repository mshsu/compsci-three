import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class FileProcessor {

    /**
     * Processes arithmetic expressions line-by-line in the given file.
     *
     * @param filePath Path to a file containing arithmetic expressions.
     */
    public static void processFile(String filePath) {
        ExpressionRaw rxp;
        LinkedInt link;
        String str;

        File infile = new File(filePath);
        try (Scanner scan = new Scanner(infile)) {
            while (scan.hasNext()) {
                // TODO: Process each line of the input file here.
                String line = scan.nextLine();
                line = line.replace("+", " + ");
                line = line.replace("*", " * ");
                line = line.replace("^", " ^ ");
                // NOTE: Added the line below to account for leading/trailing whitespace.
                line = line.trim();
                String parts[] = line.split("\\s+");
                if (parts.length == 3) {
                    rxp = new ExpressionRaw(parts[0], parts[2], parts[1]);
                    link = rxp.toExpression().eval();
                    // NOTE: Changed from below to fix leading zeroes.
                    // str = rxp + " = " + link;
                    str = rxp.toExpression() + " = " + link.cleanLinkedInt();
                    if (scan.hasNext())
                        str = str + "\n";
                    System.out.print(str);
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + infile.getPath());
        }
    }
}
