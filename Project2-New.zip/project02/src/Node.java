import java.util.Objects;

/**
 * Single unit/digit of a LinkedInt representation of an integer.
 */
public class Node {
    private int value;
    private Node next;

    public Node(int value) {
        this.value = value;
    }

    public Node(int value, Node next) {
        this.value = value;
        this.next = next;
    }

    @Override
    public String toString() {
        if (this.next == null)
            return "" + this.value;
        return this.next.toString() + this.value;
    }

    /*
    NOTE: I have replaced the equals method with one that used Objects.equals instead.
        However, in the test cases, both seem to work without issues.
        If you would prefer to use the original equals method, it is still below in the commented code.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Node node = (Node) o;
        return value == node.value && Objects.equals(next, node.next);
    }

//    @Override
//    public boolean equals(Object o) {
//        if (this == o) return true;
//        if (o == null || getClass() != o.getClass()) return false;
//        Node node = (Node) o;
//        return value == node.value && Objects.equals(next, node.next);
//    }

    public Node getNext() {
        return this.next;
    }

    public int getValue() {
        return this.value;
    }

    /**
     * Sums two LinkedInt Node representation of integers with recursion.
     * Returns a new Node representation of an integer that is the sum of the two terms.
     */
    public Node sumNode(Node other, int carry) {
        int val = (this.value + other.value + carry) % 10;
        carry = (this.value + other.value + carry) / 10;
        Node nextNode;

        if((this.next == null) & (other.next == null)) {
            if (carry > 0)
                nextNode = new Node(carry);
            else
                return new Node(val);
        }
        else if (other.next == null) {
            nextNode = this.next.sumNode(new Node(0), carry);
        }
        else if (this.next == null) {
            nextNode = other.next.sumNode(new Node(0), carry);
        }
        else {
            nextNode = this.next.sumNode(other.next, carry);
        }

        return new Node(val, nextNode);
    }

    /**
     * Multiplies two LinkedInt Node representation.
     * This is accomplished by iteratively multiplying one Node by the digits of the other Node,
     * digit by digit using multNodeHelper(), and then summing the results.
     */
    public Node multNode(Node other) {
        Node answer = new Node(0);
        Node pointer = new Node(other.value, other.next);
        Node addToAnswer;
        int zeroes = 0;

        while (pointer != null) {
            addToAnswer = this.multNodeHelper(pointer.value, 0);
            for (int i = 0; i < zeroes; i++)
                addToAnswer = new Node(0, addToAnswer);
            answer = answer.sumNode(addToAnswer, 0);
            pointer = pointer.next;
            zeroes++;
        }

        return answer;
    }

    /**
     * Recursively multiplies a LinkedInt Node representation of an int
     * by a single digit.
     */
    public Node multNodeHelper(int mult, int carry) {
        int val = (this.value * mult + carry) % 10;
        carry = (this.value * mult + carry) / 10;
        Node nextNode;

        if (this.next == null) {
            if (carry > 0)
                nextNode = new Node(carry);
            else
                return new Node(val);
        }
        else {
            nextNode = this.next.multNodeHelper(mult, carry);
        }

        return new Node(val, nextNode);
    }

    /**
     * Performs exponentiation of a LinkedInt Node representation of an int
     * using recursion. This utilizes the recursive version of the
     * <a href="https://en.wikipedia.org/wiki/Exponentiation_by_squaring#Recursive_version">
     *     exponentiation by squaring algorithm.</a>
     */
    public Node expNode(Node exp) {
        if ((exp.value == 1) & (exp.next == null)) {
//            System.out.println(this + " " + exp);
            return this;
        }
        else if ((exp.value == 0) & (exp.next == null)) {
//            System.out.println(this + " " + exp);
            return new Node(1);
        }
        else if ((exp.value % 2) == 0) {
//            System.out.println(this + " " + exp);
            return (this.multNode(this).expNode(exp.divNodeByTwo()));
        }
        else {
//            System.out.println(this + " " + exp);
            return this.multNode(
                    (this.multNode(this)).expNode(
                            (new Node(exp.value - 1, exp.next)).divNodeByTwo()
                    )
            );
        }
    }

    /**
     * Divides LinkedInt Node representation of integer by 2 using recursion.
     */
    public Node divNodeByTwo() {
        if (this.next == null) {
            return (new Node(this.value / 2)).cleanNode();
        }
        else if ((this.next.value % 2) != 0) {
            return (new Node((this.value / 2) + 5,
                    this.next.divNodeByTwo())).cleanNode();
        }
        else {
            return (new Node(this.value / 2,
                    this.next.divNodeByTwo())).cleanNode();
        }
    }

    /**
     * Removes a single leading zero from LinkedInt Node
     * representation of integer, by using recursion.
     */
    public Node cleanNode() {
        if ((this.value == 0) & (this.next == null)) {
            return null;
        }
        else if ((this.value != 0) & (this.next == null)) {
            return this;
        }
        else {
            return new Node (this.value, this.next.cleanNode());
        }
    }

    /**
     * Evaluates to see if there is a leading 0 in the
     * LinkedInt Node representation of an integer
     */
    public boolean isUnclean() {
        if ((this.value == 0) & (this.next == null)) {
            return true;
        }
        else if ((this.value != 0) & (this.next == null)) {
            return false;
        }
        else {
            return this.next.isUnclean();
        }
    }
}
