import java.util.Objects;

/**
 * Stores the raw file output in an organized fashion.
 */
public class ExpressionRaw {
    private String left;
    private String right;
    private String operation;

    public ExpressionRaw(String left, String right, String operation) {
        this.left = left;
        this.right = right;
        this.operation = operation;
    }

    @Override
    public String toString() {
        return this.left + " " + this.operation + " " + this.right;
    }


    /*
    NOTE: I have replaced the equals method with one that used Objects.equals instead.
        However, in the test cases, both seem to work without issues.
        If you would prefer to use the original equals method, it is still below in the commented code.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ExpressionRaw that = (ExpressionRaw) o;
        return Objects.equals(left, that.left) && Objects.equals(right, that.right) && Objects.equals(operation, that.operation);
    }

//    @Override
//    public boolean equals(Object o) {
//        if (this == o)
//            return true;
//        if (o == null || !(o instanceof ExpressionRaw))
//            return false;
//        ExpressionRaw other = (ExpressionRaw) o;
//        return left.equals(other.left) && right.equals(other.right) && operation.equals(other.operation);
//    }

    /**
     * Converts ExpressionRaw to Expression.
     */
    public Expression toExpression() {
        return new Expression(LinkedInt.toLinkedInt(this.left),
                LinkedInt.toLinkedInt(this.right),
                this.operation.charAt(0));
    }
}
