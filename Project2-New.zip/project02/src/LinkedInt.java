import java.util.Objects;

/**
 * Stores int as a LinkedList representation.
 * Each node stores a single digit of the integer, with the last digit as the head.
 */
public class LinkedInt {
    private Node head;

    public LinkedInt() {
    }

    public LinkedInt(Node head) {
        this.head = head;
    }

    public Node getHead() {
        return head;
    }

    @Override
    public String toString() {
        return this.head.toString();
    }

    /*
    NOTE: I have replaced the equals method with one that used Objects.equals instead.
        However, in the test cases, both seem to work without issues.
        If you would prefer to use the original equals method, it is still below in the commented code.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LinkedInt linkedInt = (LinkedInt) o;
        return Objects.equals(head, linkedInt.head);
    }

//    @Override
//    public boolean equals(Object o) {
//        if (this == o)
//            return true;
//        if (o == null || !(o instanceof LinkedInt))
//            return false;
//        LinkedInt linkedInt = (LinkedInt) o;
//        return this.head.equals(linkedInt.head);
//    }

    /**
     * Converts raw String representation of integer to LinkedInt.
     * Each digit is stored as an int.
     */
    public static LinkedInt toLinkedInt(String s) {
        LinkedInt list = new LinkedInt();
        list.head = new Node(s.charAt(0) - 48);
        Node pointer = new Node(list.head.getValue(), list.head.getNext());

        for(int i = 1; i < s.length(); i++) {
            list.head = new Node(s.charAt(i) - 48, list.head);
        }

        list = list.cleanLinkedInt();

        return list;
    }

    /**
     * Removes all leading zeroes from the LinkedInt iteratively.
     */
    public LinkedInt cleanLinkedInt() {
        if (this.head.getNext() != null) {
            while (this.head.isUnclean()) {
                if (this.head.getNext() == null) {
                    return this;
                }
                this.head = this.head.cleanNode();
            }
        }
        return this;
    }
}
