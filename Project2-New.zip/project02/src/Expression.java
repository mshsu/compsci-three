import java.util.Objects;

/**
 * Converts ExpressionRaw terms to LinkedInts and evaluates the binary operation.
 */
public class Expression {
    private LinkedInt left;
    private LinkedInt right;
    private char operation;

    public Expression(LinkedInt left, LinkedInt right, char operation) {
        this.left = left;
        this.right = right;
        this.operation = operation;
    }

    /*
    NOTE: I have replaced the equals method with one that used Objects.equals instead.
        However, in the test cases, both seem to work without issues.
        If you would prefer to use the original equals method, it is still below in the commented code.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Expression that = (Expression) o;
        return operation == that.operation && Objects.equals(left, that.left) && Objects.equals(right, that.right);
    }

//    @Override
//    public boolean equals(Object o) {
//        if (this == o)
//            return true;
//        if (o == null || !(o instanceof Expression))
//            return false;
//        Expression other = (Expression) o;
//        return operation == other.operation && left.equals(other.left) && right.equals(other.right);
//    }


    /*
    NOTE: Added this toString method.
     */
    @Override
    public String toString() {
        return this.left + " " + this.operation + " " + this.right;
    }

    /**
     * Applies the binary operation specified in the Expression
     * to the Expression's two terms, returning a single LinkedInt as the result.
     * If the operation is not valid, a null is returned.
     */
    public LinkedInt eval() {
        // Addition
        if (this.operation == '+') {
            return this.sum();
        }
        // Multiplication
        else if (this.operation == '*') {
            return this.mult();
        }
        // Exponentiation
        else if (this.operation == '^') {
            return this.exp();
        }
        else {
            return null;
        }
    }

    /**
     * Sums the two terms of the Expression, regardless of Expression operation.
     */
    public LinkedInt sum() {
        Node leftHead = this.left.getHead();
        Node rightHead = this.right.getHead();

        return new LinkedInt(leftHead.sumNode(rightHead, 0));
    }

    /**
     * Multiplies the two terms of the Expression, regardless of Expression operation.
     */
    public LinkedInt mult() {

        Node leftHead = this.left.getHead();
        Node rightHead = this.right.getHead();

        return new LinkedInt(leftHead.multNode(rightHead));
    }

    /**
     * Performs exponentiation on the left term of the Expression
     * using the right term of the Expression as the exponent.
     */
    public LinkedInt exp() {
        Node leftHead = this.left.getHead();
        Node rightHead = this.right.getHead();

        return new LinkedInt(leftHead.expNode(rightHead));
    }
}
